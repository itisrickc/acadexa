import NextAuth from "next-auth";
import authConfig from "./src/auth.config";

const { auth } = NextAuth(authConfig);

export default auth((req) => {
  const isLoggedIn = !!req.auth;

  const { pathname } = req.nextUrl;

  const isDashboard = pathname.startsWith("/dashboard");
  const isLogin = pathname === "/login";
  const isSignup = pathname === "/signup";

  if (!isLoggedIn && isDashboard) {
    return Response.redirect(new URL("/login", req.url));
  }

  if (isLoggedIn && (isLogin || isSignup)) {
    return Response.redirect(new URL("/dashboard", req.url));
  }
});

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/login",
    "/signup",
  ],
};
