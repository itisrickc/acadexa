"use client";

import { useCallback, useEffect, useRef, useState } from "react";

import { useRouter } from "next/navigation";

import AIInput from "./AIInput";
import AILoading from "./AILoading";
import AIMessage from "./AIMessage";

type Props = {
  conversationId: string;
};

type Message = {
  id?: string;
  role: "user" | "assistant";
  content: string;
  createdAt?: string;
};

type Conversation = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
};

type ConversationDetails = {
  id: string;
  title: string;
  messages: Message[];
};

export default function AIChat({
  conversationId,
}: Props) {
  const router = useRouter();

  const bottomRef =
    useRef<HTMLDivElement>(null);

  const [messages, setMessages] =
    useState<Message[]>([]);

  const [conversations, setConversations] =
    useState<Conversation[]>([]);

  const [input, setInput] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [pageLoading, setPageLoading] =
    useState(true);

  const [creatingChat, setCreatingChat] =
    useState(false);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, loading]);

  const loadConversations =
    useCallback(async () => {
      try {
        const res = await fetch(
          "/api/ai/conversations",
          {
            cache: "no-store",
          }
        );

        if (!res.ok) {
          throw new Error();
        }

        const data =
          await res.json();

        setConversations(data);
      } catch (err) {
        console.error(err);
      }
    }, []);

  const loadConversation =
    useCallback(
      async (
        id: string
      ) => {
        try {
          setPageLoading(true);

          const res =
            await fetch(
              `/api/ai/conversations/${id}`,
              {
                cache:
                  "no-store",
              }
            );

          if (!res.ok) {
            throw new Error();
          }

          const data: ConversationDetails =
            await res.json();

          setMessages(
            data.messages
          );
        } catch (err) {
          console.error(err);

          setMessages([]);
        } finally {
          setPageLoading(false);
        }
      },
      []
    );

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  useEffect(() => {
    if (!conversationId) return;

    loadConversation(
      conversationId
    );
  }, [
    conversationId,
    loadConversation,
  ]);
  